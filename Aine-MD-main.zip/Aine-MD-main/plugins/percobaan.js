/*
function handler(m, { isPrems }) {
	if (isPrems) throw false  // {
	console.log(isPrems)
global.db.data.users[m.sender].banned = true
m.reply('Kamu *terbanned* karena berkata kasar!\nHarap hubungi owner kami di bawah!')
const data = global.owner.filter(([id, isCreator]) => id && isCreator)
  this.sendContact(m.chat, data.map(([id, name]) => [id, name]), m)
// } else return !0
}
 
handler.customPrefix = /^sange|anjing|anjg|ajg|kontol|koncol|k0nt0l|kntl|kmtl|kontl|kentod|entod|ngentod|pantek|ngentot|mmk|memeq|jancok|jancuk|bajingan|bangsat|bgst|bangsad|bngsd|titid|tytyd|memek|m3m3k|pepek|p3p3k|monyet|babi|jembut|jembud|asw|sex|fuck|dick|bitch$/i
handler.command = new RegExp

module.exports = handler*/
